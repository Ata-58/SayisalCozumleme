﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace İkiyeBölme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            dataGridView1.RowCount = 100;
            dataGridView1.ColumnCount = 9;
            dataGridView1.Columns[0].HeaderText = "i";
            dataGridView1.Columns[1].HeaderText = "a";
            dataGridView1.Columns[2].HeaderText = "b";
            dataGridView1.Columns[3].HeaderText = "c";
            dataGridView1.Columns[4].HeaderText = "f(a)";
            dataGridView1.Columns[5].HeaderText = "f(b)";
            dataGridView1.Columns[6].HeaderText = "f(c)";
            dataGridView1.Columns[7].HeaderText = "f(a).f(c)";
            dataGridView1.Columns[8].HeaderText = "|b-a|";

            double a = -1;
            double b = 1;
            double c;
            for (int i = 0; i < 20; i++)
            {
                c = (a + b) / 2;
                dataGridView1[0, i].Value = i;
                dataGridView1[1, i].Value = a;
                dataGridView1[2, i].Value = b;
                dataGridView1[3, i].Value = c;
                dataGridView1[4, i].Value = f(a);
                dataGridView1[5, i].Value = f(b);
                dataGridView1[6, i].Value = f(c);
                dataGridView1[7, i].Value = f(a) * f(c);
                dataGridView1[8, i].Value = Math.Abs(b - a);
                if (f(a) * f(c) < 0)
                {
                    b = c;
                }
                else
                {
                    a = c;
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

            dataGridView1.RowCount = 100;
            dataGridView1.ColumnCount = 9;
            dataGridView1.Columns[0].HeaderText = "i";
            dataGridView1.Columns[1].HeaderText = "a";
            dataGridView1.Columns[2].HeaderText = "b";
            dataGridView1.Columns[3].HeaderText = "c";
            dataGridView1.Columns[4].HeaderText = "f(a)";
            dataGridView1.Columns[5].HeaderText = "f(b)";
            dataGridView1.Columns[6].HeaderText = "f(c)";
            dataGridView1.Columns[7].HeaderText = "f(a).f(c)";
            dataGridView1.Columns[8].HeaderText = "|b-a|";

            double a = -1;
            double b = 1;
            double c;
            double eps = 1e-4;
            int i = 0;
            do
            {
                c = (a + b) / 2;
                dataGridView1[0, i].Value = i;
                dataGridView1[1, i].Value = a;
                dataGridView1[2, i].Value = b;
                dataGridView1[3, i].Value = c;
                dataGridView1[4, i].Value = f(a);
                dataGridView1[5, i].Value = f(b);
                dataGridView1[6, i].Value = f(c);
                dataGridView1[7, i].Value = f(a) * f(c);
                dataGridView1[8, i].Value = Math.Abs(b - a);
                if (f(a) * f(c) < 0)
                {
                    b = c;
                }
                else
                {
                    a = c;
                }
                i++;
            } while (Math.Abs(b - a) > eps);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            double a = -1;
            double b = 1;
            double eps = 1e-2;
            double x = ikiböl(a, b, eps);
            label1.Text = x.ToString();
            label1.Text = ikiböl(a, b, 10).ToString();
        }
        private double f(double x)
        {
            return x * Math.Exp(-x) + Math.Pow(x, 3.0) + 1;
        }
        private double ikiböl(double a, double b, double eps)
        {
            double c;
            do
            {
                c = (a + b) / 2.0;
                if (f(a) * f(c) < 0)
                {
                    b = c;
                }
                else
                {
                    a = c;
                }
            } while (Math.Abs(b - a) > eps);

            return c;
        }
        private double ikiböl(double a, double b, int n)
        {
            double c=0;
            for (int i = 0; i < n; i++)
            {
                c = (a + b) / 2.0;
                if (f(a) * f(c) < 0)
                {
                    b = c;
                }
                else
                {
                    a = c;
                }
            } 

            return c;
        }
    }
}
