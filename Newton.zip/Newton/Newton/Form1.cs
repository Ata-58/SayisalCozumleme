﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Newton
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x0 = Convert.ToDouble(textBox1.Text);
            dataGridView1.ColumnCount = 6;
            dataGridView1.RowCount = 100;
            dataGridView1.Columns[0].HeaderText = "i";
            dataGridView1.Columns[1].HeaderText = "x_i";
            dataGridView1.Columns[2].HeaderText = "f(x_i)";
            dataGridView1.Columns[3].HeaderText = "f'(x_i)";
            dataGridView1.Columns[4].HeaderText = "x_i+1";
            dataGridView1.Columns[5].HeaderText = "|Dx|";
            double xi=x0;
            double xi1;
            for (int i = 0; i < 10; i++)
            {
                xi1 = xi - f(xi) / f1(xi);
                dataGridView1[0, i].Value = i;
                dataGridView1[1, i].Value = xi;
                dataGridView1[2, i].Value = f(xi);
                dataGridView1[3, i].Value = f1(xi);
                dataGridView1[4, i].Value = xi1;
                dataGridView1[5, i].Value = Math.Abs(xi-xi1);
                xi = xi1;
            }

        }

 
        private void button2_Click(object sender, EventArgs e)
        {
            double x0 = Convert.ToDouble(textBox1.Text);
            dataGridView1.ColumnCount = 6;
            dataGridView1.RowCount = 100;
            dataGridView1.Columns[0].HeaderText = "i";
            dataGridView1.Columns[1].HeaderText = "x_i";
            dataGridView1.Columns[2].HeaderText = "f(x_i)";
            dataGridView1.Columns[3].HeaderText = "f'(x_i)";
            dataGridView1.Columns[4].HeaderText = "x_i+1";
            dataGridView1.Columns[5].HeaderText = "|Dx|";
            double xi = x0;
            double xi1;
            double eps = 1e-4;
            int i = 0;
            double fark;
            do
            {
                xi1 = xi - f(xi) / f1(xi);
                dataGridView1[0, i].Value = i;
                dataGridView1[1, i].Value = xi;
                dataGridView1[2, i].Value = f(xi);
                dataGridView1[3, i].Value = f1(xi);
                dataGridView1[4, i].Value = xi1;
                dataGridView1[5, i].Value = Math.Abs(xi - xi1);
                fark = Math.Abs(xi - xi1);
                xi = xi1;
                i++;
            } while (fark > eps);

        }



        private void button3_Click(object sender, EventArgs e)
        {
            double eps = 1e-4;
            double x = newton(0,eps);
            textBox1.Text = x.ToString();
        }

        //sınav kod kısmı
        private double newton(double x,double eps)
        {
            double x1;
            double fark;
            do
            {
                x1 = x - f(x) / f1(x);
                fark = Math.Abs(x1 - x);
                x = x1;
            } while (fark > eps);
            return x;
        }
        private double f(double x)
        {
            double fx = x * Math.Exp(-x) + Math.Pow(x, 3.0) + 1;
            return fx;
        }
        private double f1(double x)
        {
            double f1x = (1 - x) * Math.Exp(-x) + 3 * Math.Pow(x, 2.0);
            return f1x;
        }
    }
}
